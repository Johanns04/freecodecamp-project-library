/*
*
*
*       Complete the API routing below
*       
*       
*/

'use strict';
require('dotenv').config();
const mongoose = require('mongoose');
mongoose.connect(process.env.DB, { useNewUrlParser: true, useUnifiedTopology: true });

const bookSchema = mongoose.Schema({
	title: String,
	comments: [String],
	commentcount: Number
});

const Book = mongoose.model('Book', bookSchema);

module.exports = function (app) {

  app.route('/api/books')
    .get(function (req, res){
      //response will be array of book objects
      //json res format: [{"_id": bookid, "title": book_title, "commentcount": num_of_comments },...]
	  Book.find({}).select('-__V -comments').exec('find', (err, data)=>{
		if(err) console.log("Error in Get");
		res.json(data);
	  });
    })
    
    .post(function (req, res){
      let title = req.body.title;
      //response will contain new book object including atleast _id and title
	  console.log(title, "<== title");
	  if(!title){
		  res.send("missing required field title");
	  }else{
		  let newBook = new Book({
			  'title': title,
			  commentcount: 0
		  });
		  
		  newBook.save((err, data)=>{
			  if(err) console.log("Error in post.");
			  res.send({
				'title': title,
				_id: data._id
			  });
		  });
	  }
	  
    })
    
    .delete(function(req, res){
      //if successful response will be 'complete delete successful'
	  Book.deleteMany({}, (err)=>{
		if(err){
			console.log("Error in Delete Many.");
			return;
		}
		res.send('complete delete successful');
	  });
    });



  app.route('/api/books/:id')
    .get(function (req, res){
      let bookid = req.params.id;

      //json res format: {"_id": bookid, "title": book_title, "comments": [comment,comment,...]}
	  Book.findById(bookid).select('-__V -commentcount').exec('find', (err, data)=>{
		  if(err) console.log("Error in id Get");
		  if(data.length === 0){
			res.send("no book exists");
		  }else{
			res.json({
				'_id': data[0]._id,
				'title': data[0].title,
				'comments': data[0].comments
			});
		  }
	  });
    })
    
    .post(function(req, res){
      let bookid = req.params.id;
      let comment = req.body.comment;
      //json res format same as .get
	  if(!comment){
		  res.send('missing required field comment');
	  }else{
			Book.findById(bookid, (err, book)=>{
				if(err) res.send("no book exists!");;
				if(!book){
					res.send("no book exists");
				}else{
					//console.log(!book);
					book.comments.push(comment);
					book.commentcount++;
					book.save((err, data)=>{
						if(err) console.log("Error in saving comment.");
						res.send({
							'comments': data.comments,
							'_id': data._id,
							'title': data.title
							
						});
					});
				}
				
			});
	  }
    })
    
    .delete(function(req, res){
      let bookid = req.params.id;

      //if successful response will be 'delete successful'
      Book.deleteOne({_id: bookid}, (err, data)=>{
		  if(err) console.log("Error in delete One.");
		  if(data.deletedCount === 1){
			res.send("delete successful");
			return;
		  }else{
			res.send("no book exists");
		  }
      });
    });
  
};
